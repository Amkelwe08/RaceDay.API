# Copilot Instructions

## Project Guidelines
- For the Race Day Part 3 implementation, preserve the Part 1 database schema and relationships, use API-loaded data rather than hard-coded production sample names, maintain ownership and per-user visibility, avoid duplicate seed records, and use the exact Part 1 examples (Amkelwe Tuta, Abulele Nkabi, Inganathi Mancam, Uyanda Malindi, specified events/categories/enrolments/results) in development/testing/demo preparation.