using System.Net;
using System.Net.Http.Json;
using RaceDay.Contracts;

namespace RaceDay.Api.Tests;

public class AuthenticationAndAuthorizationTests(RaceDayApiFactory factory) : IClassFixture<RaceDayApiFactory>
{
    [Fact]
    public async Task Authentication_and_role_rules_are_enforced()
    {
        using var anonymousClient = factory.CreateClient();
        var unauthenticatedProfile = await anonymousClient.GetAsync("/api/profile/me");
        Assert.Equal(HttpStatusCode.Unauthorized, unauthenticatedProfile.StatusCode);

        var organiserClient = factory.CreateClient();
        var organiserLogin = await organiserClient.PostAsJsonAsync("/api/auth/login", new LoginRequest
        {
            Email = "organiser@test.example", Password = "Password1!"
        });
        Assert.Equal(HttpStatusCode.OK, organiserLogin.StatusCode);

        var participantClient = factory.CreateClient();
        var participantEmail = $"participant-{Guid.NewGuid():N}@example.com";
        var registerParticipant = await participantClient.PostAsJsonAsync("/api/auth/register", new RegisterRequest
        {
            FullName = "Inganathi Mancam", Email = participantEmail, Password = "Password1!", PhoneNumber = "0720000000"
        });
        Assert.Equal(HttpStatusCode.Created, registerParticipant.StatusCode);

        var loginClient = factory.CreateClient();
        var validLogin = await loginClient.PostAsJsonAsync("/api/auth/login", new LoginRequest
        {
            Email = participantEmail, Password = "Password1!"
        });
        Assert.Equal(HttpStatusCode.OK, validLogin.StatusCode);

        var invalidLogin = await anonymousClient.PostAsJsonAsync("/api/auth/login", new LoginRequest
        {
            Email = participantEmail, Password = "WrongPassword1!"
        });
        Assert.Equal(HttpStatusCode.Unauthorized, invalidLogin.StatusCode);

        var eventRequest = new CreateEventRequest
        {
            Name = "Gqeberha Beachfront Marathon", Description = "Part 1 demonstration event", EventDate = DateTime.UtcNow.AddDays(30),
            Location = "Test Park"
        };

        var participantEvent = await participantClient.PostAsJsonAsync("/api/events", eventRequest);
        Assert.Equal(HttpStatusCode.Forbidden, participantEvent.StatusCode);

        var organiserEvent = await organiserClient.PostAsJsonAsync("/api/events", eventRequest);
        Assert.Equal(HttpStatusCode.Created, organiserEvent.StatusCode);
        var createdEvent = await organiserEvent.Content.ReadFromJsonAsync<EventDto>();
        Assert.NotNull(createdEvent);

        var organiserCategory = await organiserClient.PostAsJsonAsync($"/api/events/{createdEvent.Id}/categories", new CreateCategoryRequest
        {
            EventId = createdEvent.Id, CategoryName = "10km Fun Run", DistanceKm = 10, EntryFee = 100, MaxParticipants = 100
        });
        Assert.Equal(HttpStatusCode.Created, organiserCategory.StatusCode);
        var createdCategory = await organiserCategory.Content.ReadFromJsonAsync<CategoryDto>();
        Assert.NotNull(createdCategory);

        var participantCategory = await participantClient.PostAsJsonAsync($"/api/events/{createdEvent.Id}/categories", new CreateCategoryRequest
        {
            EventId = createdEvent.Id, CategoryName = "Restricted", DistanceKm = 5, EntryFee = 50, MaxParticipants = 100
        });
        Assert.Equal(HttpStatusCode.Forbidden, participantCategory.StatusCode);

        var enrolment = await participantClient.PostAsJsonAsync("/api/enrolments", new CreateEnrolmentRequest
        {
            CategoryId = createdCategory.Id
        });
        Assert.Equal(HttpStatusCode.Created, enrolment.StatusCode);
    }
}
