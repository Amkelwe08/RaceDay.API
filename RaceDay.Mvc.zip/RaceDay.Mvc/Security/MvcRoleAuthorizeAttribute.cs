using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDay.Mvc.Security;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
public sealed class MvcRoleAuthorizeAttribute(params string[] allowedRoles) : Attribute, IAsyncAuthorizationFilter
{
    private readonly string[] _allowedRoles = allowedRoles;

    public Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        var userId = context.HttpContext.Session.GetInt32("UserId");
        var role = context.HttpContext.Session.GetString("Role");

        if (!userId.HasValue || string.IsNullOrWhiteSpace(role))
        {
            context.Result = new RedirectToActionResult("Login", "Account", null);
        }
        else if (_allowedRoles.Length > 0 && !_allowedRoles.Contains(role, StringComparer.OrdinalIgnoreCase))
        {
            context.Result = new RedirectToActionResult("Index", "Home", null);
        }

        return Task.CompletedTask;
    }
}
