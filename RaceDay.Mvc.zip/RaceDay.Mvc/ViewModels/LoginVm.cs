using System.ComponentModel.DataAnnotations;

namespace RaceDay.Mvc.ViewModels;

public sealed class LoginVm
{
    [Required, EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required, DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;
}
