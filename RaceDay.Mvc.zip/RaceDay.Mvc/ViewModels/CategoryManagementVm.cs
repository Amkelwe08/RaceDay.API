using System.ComponentModel.DataAnnotations;

namespace RaceDay.Mvc.ViewModels;

public sealed class CategoryManagementVm
{
    public int EventId { get; set; }
    public int? Id { get; set; }
    [Required] public string CategoryName { get; set; } = string.Empty;
    [Range(0.01, 10000)] public decimal DistanceKm { get; set; }
    [Range(0, double.MaxValue)] public decimal EntryFee { get; set; }
    [Range(1, int.MaxValue)] public int MaxParticipants { get; set; }
}
