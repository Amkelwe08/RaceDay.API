using RaceDay.Contracts;

namespace RaceDay.Mvc.ViewModels;

public sealed class ParticipantDashboardVm
{
    public IReadOnlyList<EventDto> Events { get; init; } = [];
    public IReadOnlyList<EnrolmentDto> Enrolments { get; init; } = [];
    public IReadOnlyList<ResultDto> Results { get; init; } = [];
}
