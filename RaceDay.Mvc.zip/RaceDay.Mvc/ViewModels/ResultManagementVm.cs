using System.ComponentModel.DataAnnotations;

namespace RaceDay.Mvc.ViewModels;

public sealed class ResultManagementVm
{
    public int EventId { get; set; }
    [Required] public int EnrolmentId { get; set; }
    [Range(0, double.MaxValue)] public decimal FinishTimeSeconds { get; set; }
    [Range(1, int.MaxValue)] public int FinishPosition { get; set; }
    public string Status { get; set; } = "Finished";
}
