using System.ComponentModel.DataAnnotations;
using RaceDay.Contracts;

namespace RaceDay.Mvc.ViewModels;

public sealed class EventManagementVm
{
    public int? Id { get; set; }
    [Required] public string Name { get; set; } = string.Empty;
    [Required] public string Description { get; set; } = string.Empty;
    [DataType(DataType.DateTime), Required] public DateTime EventDate { get; set; } = DateTime.Today.AddDays(30);
    [Required] public string Location { get; set; } = string.Empty;
    public string? BannerImageUrl { get; set; }
    public IFormFile? Banner { get; set; }

    public EventManagementVm() { }
    public EventManagementVm(EventDto item)
    {
        Id = item.Id; Name = item.Name; Description = item.Description; EventDate = item.EventDate;
        Location = item.Location;
        BannerImageUrl = item.BannerImageUrl;
    }
}
