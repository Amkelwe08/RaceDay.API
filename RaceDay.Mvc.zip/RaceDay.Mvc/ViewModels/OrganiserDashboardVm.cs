namespace RaceDay.Mvc.ViewModels;

public sealed class OrganiserDashboardVm
{
    public string OrganiserName { get; init; } = string.Empty;
    public IReadOnlyList<OrganiserEventSummaryVm> Events { get; init; } = [];
    public int CategoryCount { get; init; }
    public int EnrolmentCount { get; init; }
}

public sealed class OrganiserEventSummaryVm
{
    public int EventId { get; init; }
    public string Name { get; init; } = string.Empty;
    public DateTime EventDate { get; init; }
    public string Location { get; init; } = string.Empty;
    public int EnrolmentCount { get; init; }
}
