using Microsoft.AspNetCore.Mvc;
using RaceDay.Contracts;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

public sealed class AccountController(RaceDayApiClient api, ILogger<AccountController> logger) : Controller
{
    [HttpGet]
    public IActionResult Register() => View();

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterVm model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid) return View(model);

        try
        {
            using var response = await api.SendAsync(HttpMethod.Post, "api/auth/register", new RegisterRequest
            {
                FullName = model.FullName,
                Email = model.Email,
                Password = model.Password,
                PhoneNumber = model.PhoneNumber
            }, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                ModelState.AddModelError(string.Empty, await ReadApiErrorAsync(response, "Registration could not be completed."));
                return View(model);
            }

            TempData["Success"] = "Registration successful. Please log in.";
            return RedirectToAction(nameof(Login));
        }
        catch (HttpRequestException exception)
        {
            logger.LogWarning(exception, "Registration API request failed with a transport error.");
            ModelState.AddModelError(string.Empty, "The registration API could not be reached. Please check that the API is running.");
            return View(model);
        }
    }

    [HttpGet]
    public IActionResult Login() => View();

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginVm model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid) return View(model);

        try
        {
            using var response = await api.SendAsync(HttpMethod.Post, "api/auth/login", new LoginRequest
            {
                Email = model.Email,
                Password = model.Password
            }, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                ModelState.AddModelError(string.Empty, await ReadApiErrorAsync(response, "Invalid email or password."));
                return View(model);
            }

            var auth = await api.ReadAsync<AuthResponse>(response, cancellationToken);
            if (auth?.User is null)
            {
                ModelState.AddModelError(string.Empty, "The login response could not be read.");
                return View(model);
            }

            var apiCookie = RaceDayApiClient.ExtractSessionCookie(response);
            if (!string.IsNullOrWhiteSpace(apiCookie)) HttpContext.Session.SetString("ApiSessionCookie", apiCookie);
            HttpContext.Session.SetInt32("UserId", auth.User.Id);
            HttpContext.Session.SetString("Role", auth.User.Role);
            HttpContext.Session.SetString("DisplayName", auth.User.FullName);

            var controller = auth.User.Role.Equals("Organiser", StringComparison.OrdinalIgnoreCase) ? "Organiser" : "Participant";
            return RedirectToAction("Index", controller);
        }
        catch (HttpRequestException exception)
        {
            logger.LogWarning(exception, "Login API request failed with a transport error.");
            ModelState.AddModelError(string.Empty, "The login service is unavailable. Please try again.");
            return View(model);
        }
    }

    private static async Task<string> ReadApiErrorAsync(HttpResponseMessage response, string fallback)
    {
        var content = await response.Content.ReadAsStringAsync();
        if (string.IsNullOrWhiteSpace(content)) return fallback;

        try
        {
            using var document = System.Text.Json.JsonDocument.Parse(content);
            if (document.RootElement.TryGetProperty("message", out var message) && message.ValueKind == System.Text.Json.JsonValueKind.String)
            {
                return message.GetString() ?? fallback;
            }

            if (document.RootElement.TryGetProperty("detail", out var detail) && detail.ValueKind == System.Text.Json.JsonValueKind.String)
            {
                return detail.GetString() ?? fallback;
            }
        }
        catch (System.Text.Json.JsonException)
        {
        }

        return fallback;
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout(CancellationToken cancellationToken)
    {
        try
        {
            using var response = await api.SendAsync(HttpMethod.Post, "api/auth/logout", cancellationToken: cancellationToken);
            response.Dispose();
        }
        catch (HttpRequestException)
        {
            TempData["Error"] = "The API session could not be closed, but you have been signed out of this site.";
        }

        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Home");
    }
}
