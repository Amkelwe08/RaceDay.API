using Microsoft.AspNetCore.Mvc;
using RaceDay.Contracts;
using RaceDay.Mvc.Security;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

[MvcRoleAuthorize("Organiser")]
public sealed class OrganiserController(RaceDayApiClient api) : Controller
{
    [HttpGet]
    public async Task<IActionResult> Index(CancellationToken cancellationToken)
    {
        var events = await api.GetMyEventsAsync(cancellationToken);
        var categoryCount = 0;
        var enrolmentCount = 0;
        var summaries = new List<OrganiserEventSummaryVm>(events.Count);
        foreach (var item in events)
        {
            categoryCount += (await api.GetCategoriesAsync(item.Id, cancellationToken)).Count;
            var eventEnrolmentCount = (await api.GetEventEnrolmentsAsync(item.Id, cancellationToken)).Count;
            enrolmentCount += eventEnrolmentCount;
            summaries.Add(new OrganiserEventSummaryVm
            {
                EventId = item.Id,
                Name = item.Name,
                EventDate = item.EventDate,
                Location = item.Location,
                EnrolmentCount = eventEnrolmentCount
            });
        }

        return View(new OrganiserDashboardVm
        {
            OrganiserName = HttpContext.Session.GetString("DisplayName") ?? "Organiser",
            Events = summaries,
            CategoryCount = categoryCount,
            EnrolmentCount = enrolmentCount
        });
    }

    [HttpGet]
    public IActionResult CreateEvent() => View("EventForm", new EventManagementVm());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateEvent(EventManagementVm model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid) return View("EventForm", model);
        try
        {
            var createdEvent = await api.PostAsync<CreateEventRequest, EventDto>("api/events", ToRequest(model), cancellationToken);
            if (model.Banner is not null)
            {
                using var response = await api.UploadFileAsync($"api/events/{createdEvent.Id}/banner", model.Banner, cancellationToken);
                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(string.Empty, "The event was created, but its banner could not be uploaded.");
                    return View("EventForm", model);
                }
            }
            TempData["Success"] = "Event created.";
            return RedirectToAction(nameof(Index));
        }
        catch (HttpRequestException) { ModelState.AddModelError(string.Empty, "The event could not be created."); return View("EventForm", model); }
    }

    [HttpGet]
    public async Task<IActionResult> EditEvent(int id, CancellationToken cancellationToken)
    {
        var item = await GetOwnedEventAsync(id, cancellationToken);
        return item is null ? NotFound() : View("EventForm", new EventManagementVm(item));
    }

    [HttpGet]
    public async Task<IActionResult> Event(int id, CancellationToken cancellationToken)
    {
        var item = await GetOwnedEventAsync(id, cancellationToken);
        return item is null ? NotFound() : View(item);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EditEvent(EventManagementVm model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid || model.Id is null) return View("EventForm", model);
        try
        {
            var updatedEvent = await api.PutAsync<UpdateEventRequest, EventDto>($"api/events/{model.Id}", ToUpdateRequest(model), cancellationToken);
            if (model.Banner is not null)
            {
                using var response = await api.UploadFileAsync($"api/events/{model.Id}/banner", model.Banner, cancellationToken);
                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(string.Empty, "The event was saved, but its banner could not be uploaded.");
                    return View("EventForm", model);
                }
            }
            TempData["Success"] = "Event updated.";
            return RedirectToAction(nameof(Index));
        }
        catch (HttpRequestException) { ModelState.AddModelError(string.Empty, "The event could not be updated."); return View("EventForm", model); }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteEvent(int id, CancellationToken cancellationToken)
    {
        try { await api.DeleteAsync($"api/events/{id}", cancellationToken); TempData["Success"] = "Event deleted."; }
        catch (HttpRequestException) { TempData["Error"] = "The event could not be deleted."; }
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Categories(int eventId, CancellationToken cancellationToken)
    {
        var item = await GetOwnedEventAsync(eventId, cancellationToken);
        if (item is null) return NotFound();
        ViewBag.Event = item;
        return View(await api.GetCategoriesAsync(eventId, cancellationToken));
    }

    [HttpGet]
    public async Task<IActionResult> CreateCategory(int eventId, CancellationToken cancellationToken)
    {
        var item = await GetOwnedEventAsync(eventId, cancellationToken);
        return item is null ? NotFound() : View("CategoryForm", new CategoryManagementVm { EventId = eventId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateCategory(CategoryManagementVm model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid) return View("CategoryForm", model);
        try
        {
            await api.PostAsync<CreateCategoryRequest, CategoryDto>($"api/events/{model.EventId}/categories", new CreateCategoryRequest { EventId = model.EventId, CategoryName = model.CategoryName, DistanceKm = model.DistanceKm, EntryFee = model.EntryFee, MaxParticipants = model.MaxParticipants }, cancellationToken);
            TempData["Success"] = "Category created.";
            return RedirectToAction(nameof(Categories), new { eventId = model.EventId });
        }
        catch (HttpRequestException) { ModelState.AddModelError(string.Empty, "The category could not be created."); return View("CategoryForm", model); }
    }

    [HttpGet]
    public async Task<IActionResult> EditCategory(int eventId, int id, CancellationToken cancellationToken)
    {
        if (await GetOwnedEventAsync(eventId, cancellationToken) is null) return NotFound();
        var category = (await api.GetCategoriesAsync(eventId, cancellationToken)).SingleOrDefault(item => item.Id == id);
        return category is null
            ? NotFound()
            : View("CategoryForm", new CategoryManagementVm { EventId = eventId, Id = category.Id, CategoryName = category.CategoryName, DistanceKm = category.DistanceKm, EntryFee = category.EntryFee, MaxParticipants = category.MaxParticipants });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EditCategory(CategoryManagementVm model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid || model.Id is null) return View("CategoryForm", model);
        try
        {
            await api.PutAsync<CreateCategoryRequest, CategoryDto>($"api/categories/{model.Id}", new CreateCategoryRequest { EventId = model.EventId, CategoryName = model.CategoryName, DistanceKm = model.DistanceKm, EntryFee = model.EntryFee, MaxParticipants = model.MaxParticipants }, cancellationToken);
            TempData["Success"] = "Category updated.";
        }
        catch (HttpRequestException) { TempData["Error"] = "The category could not be updated."; }
        return RedirectToAction(nameof(Categories), new { eventId = model.EventId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteCategory(int eventId, int id, CancellationToken cancellationToken)
    {
        try { await api.DeleteAsync($"api/categories/{id}", cancellationToken); TempData["Success"] = "Category deleted."; }
        catch (HttpRequestException) { TempData["Error"] = "The category could not be deleted."; }
        return RedirectToAction(nameof(Categories), new { eventId });
    }

    [HttpGet]
    public async Task<IActionResult> Enrolments(int eventId, CancellationToken cancellationToken)
    {
        var item = await GetOwnedEventAsync(eventId, cancellationToken);
        if (item is null) return NotFound();
        ViewBag.Event = item;
        return View(await api.GetEventEnrolmentsAsync(eventId, cancellationToken));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateEnrolmentStatus(int eventId, int id, string status, CancellationToken cancellationToken)
    {
        try { await api.PutAsync<UpdateEnrolmentStatusRequest, EnrolmentDto>($"api/enrolments/{id}/status", new UpdateEnrolmentStatusRequest { Status = status }, cancellationToken); TempData["Success"] = "Enrolment status updated."; }
        catch (HttpRequestException) { TempData["Error"] = "The enrolment status could not be updated."; }
        return RedirectToAction(nameof(Enrolments), new { eventId });
    }

    [HttpGet]
    public async Task<IActionResult> Results(int eventId, CancellationToken cancellationToken)
    {
        var item = await GetOwnedEventAsync(eventId, cancellationToken);
        if (item is null) return NotFound();
        ViewBag.Event = item;
        ViewBag.Enrolments = (await api.GetEventEnrolmentsAsync(eventId, cancellationToken))
            .Where(enrolment => !string.Equals(enrolment.Status, "Cancelled", StringComparison.OrdinalIgnoreCase))
            .ToList();
        return View(await api.GetEventResultsAsync(eventId, cancellationToken));
    }

    [HttpGet]
    public async Task<IActionResult> CreateResult(int eventId, CancellationToken cancellationToken)
    {
        var item = await GetOwnedEventAsync(eventId, cancellationToken);
        if (item is null) return NotFound();
        ViewBag.Enrolments = (await api.GetEventEnrolmentsAsync(eventId, cancellationToken))
            .Where(enrolment => !string.Equals(enrolment.Status, "Cancelled", StringComparison.OrdinalIgnoreCase))
            .ToList();
        return View("ResultForm", new ResultManagementVm { EventId = eventId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateResult(ResultManagementVm model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            ViewBag.Enrolments = (await api.GetEventEnrolmentsAsync(model.EventId, cancellationToken))
                .Where(enrolment => !string.Equals(enrolment.Status, "Cancelled", StringComparison.OrdinalIgnoreCase))
                .ToList();
            return View("ResultForm", model);
        }
        try
        {
            await api.PostAsync<CreateResultRequest, ResultDto>("api/results", new CreateResultRequest { EnrolmentId = model.EnrolmentId, FinishTimeSeconds = model.FinishTimeSeconds, FinishPosition = model.FinishPosition, Status = model.Status }, cancellationToken);
            TempData["Success"] = "Result recorded.";
            return RedirectToAction(nameof(Results), new { eventId = model.EventId });
        }
        catch (HttpRequestException)
        {
            ViewBag.Enrolments = (await api.GetEventEnrolmentsAsync(model.EventId, cancellationToken))
                .Where(enrolment => !string.Equals(enrolment.Status, "Cancelled", StringComparison.OrdinalIgnoreCase))
                .ToList();
            ModelState.AddModelError(string.Empty, "The result could not be recorded. It may already exist for this enrolment.");
            return View("ResultForm", model);
        }
    }

    private static CreateEventRequest ToRequest(EventManagementVm model) => new() { Name = model.Name, Description = model.Description, EventDate = model.EventDate, Location = model.Location };
    private static UpdateEventRequest ToUpdateRequest(EventManagementVm model) => new() { Name = model.Name, Description = model.Description, EventDate = model.EventDate, Location = model.Location };

    private async Task<EventDto?> GetOwnedEventAsync(int eventId, CancellationToken cancellationToken)
        => (await api.GetMyEventsAsync(cancellationToken)).SingleOrDefault(item => item.Id == eventId);
}
