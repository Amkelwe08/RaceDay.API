using Microsoft.AspNetCore.Mvc;
using RaceDay.Contracts;
using RaceDay.Mvc.Security;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

[MvcRoleAuthorize("Participant")]
public sealed class ParticipantController(RaceDayApiClient api) : Controller
{
    [HttpGet]
    public async Task<IActionResult> Index(CancellationToken cancellationToken)
    {
        var events = await api.GetEventsAsync(cancellationToken);
        var enrolments = await api.GetMyEnrolmentsAsync(cancellationToken);
        var results = await api.GetMyResultsAsync(cancellationToken);
        return View(new ParticipantDashboardVm { Events = events, Enrolments = enrolments, Results = results });
    }

    [HttpGet]
    public async Task<IActionResult> Event(int id, CancellationToken cancellationToken)
    {
        var item = await api.GetEventAsync(id, cancellationToken);
        if (item is null) return NotFound();
        ViewBag.Event = item;
        return View(await api.GetCategoriesAsync(id, cancellationToken));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Enrol(CreateEnrolmentRequest request, CancellationToken cancellationToken)
    {
        try
        {
            await api.PostAsync<CreateEnrolmentRequest, EnrolmentDto>("api/enrolments", request, cancellationToken);
            TempData["Success"] = "Your enrolment was submitted.";
        }
        catch (HttpRequestException)
        {
            ModelState.AddModelError(string.Empty, "The enrolment could not be submitted.");
        }

        return RedirectToAction(nameof(Index));
    }
}
