using System.Net.Http.Json;
using System.Text.Json;
using RaceDay.Contracts;

namespace RaceDay.Mvc.Services;

public sealed class RaceDayApiClient(IHttpClientFactory factory, IHttpContextAccessor httpContextAccessor)
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    private HttpClient CreateClient() => factory.CreateClient("RaceDayApi");

    private HttpRequestMessage CreateRequest(HttpMethod method, string url)
    {
        var request = new HttpRequestMessage(method, url);
        var apiCookie = httpContextAccessor.HttpContext?.Session.GetString("ApiSessionCookie");
        if (!string.IsNullOrWhiteSpace(apiCookie))
        {
            request.Headers.TryAddWithoutValidation("Cookie", apiCookie);
        }

        return request;
    }

    public async Task<HttpResponseMessage> UploadFileAsync(string relativeUri, IFormFile file, CancellationToken cancellationToken = default)
    {
        using var request = CreateRequest(HttpMethod.Post, relativeUri);
        using var form = new MultipartFormDataContent();
        await using var stream = file.OpenReadStream();
        using var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(file.ContentType);
        form.Add(fileContent, "file", file.FileName);
        request.Content = form;
        return await CreateClient().SendAsync(request, cancellationToken);
    }

    public async Task<IReadOnlyList<EventDto>> GetMyEventsAsync(CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Get, "api/events/mine", cancellationToken: cancellationToken);
        return await ReadAsync<List<EventDto>>(response, cancellationToken) ?? [];
    }

    public async Task<IReadOnlyList<CategoryDto>> GetCategoriesAsync(int eventId, CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Get, $"api/events/{eventId}/categories", cancellationToken: cancellationToken);
        return await ReadAsync<List<CategoryDto>>(response, cancellationToken) ?? [];
    }

    public async Task<IReadOnlyList<EnrolmentDto>> GetMyEnrolmentsAsync(CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Get, "api/enrolments/mine", cancellationToken: cancellationToken);
        return await ReadAsync<List<EnrolmentDto>>(response, cancellationToken) ?? [];
    }

    public async Task<IReadOnlyList<EnrolmentDto>> GetEventEnrolmentsAsync(int eventId, CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Get, $"api/enrolments/event/{eventId}", cancellationToken: cancellationToken);
        return await ReadAsync<List<EnrolmentDto>>(response, cancellationToken) ?? [];
    }

    public async Task<IReadOnlyList<ResultDto>> GetMyResultsAsync(CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Get, "api/results/mine", cancellationToken: cancellationToken);
        return await ReadAsync<List<ResultDto>>(response, cancellationToken) ?? [];
    }

    public async Task<IReadOnlyList<ResultDto>> GetEventResultsAsync(int eventId, CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Get, $"api/results/event/{eventId}", cancellationToken: cancellationToken);
        return await ReadAsync<List<ResultDto>>(response, cancellationToken) ?? [];
    }

    public async Task<HttpResponseMessage> SendAsync(HttpMethod method, string url, object? body = null, CancellationToken cancellationToken = default)
    {
        using var request = CreateRequest(method, url);
        if (body is not null)
        {
            request.Content = JsonContent.Create(body);
        }

        return await CreateClient().SendAsync(request, cancellationToken);
    }

    public async Task<T?> ReadAsync<T>(HttpResponseMessage response, CancellationToken cancellationToken = default)
    {
        if (!response.IsSuccessStatusCode)
        {
            return default;
        }

        var json = await response.Content.ReadAsStringAsync(cancellationToken);
        return JsonSerializer.Deserialize<T>(json, JsonOptions);
    }

    public static string? ExtractSessionCookie(HttpResponseMessage response)
    {
        if (!response.Headers.TryGetValues("Set-Cookie", out var values))
        {
            return null;
        }

        var sessionHeader = values.FirstOrDefault(value =>
            value.StartsWith(".AspNetCore.Session=", StringComparison.OrdinalIgnoreCase));
        return sessionHeader?.Split(';', 2)[0];
    }

    public async Task<IReadOnlyList<EventDto>> GetEventsAsync(CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Get, "api/events", cancellationToken: cancellationToken);
        return await ReadAsync<List<EventDto>>(response, cancellationToken) ?? [];
    }

    public async Task<EventDto?> GetEventAsync(int eventId, CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Get, $"api/events/{eventId}", cancellationToken: cancellationToken);
        return await ReadAsync<EventDto>(response, cancellationToken);
    }

    public async Task<TResponse> PostAsync<TRequest, TResponse>(string relativeUri, TRequest request, CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Post, relativeUri, request, cancellationToken);
        response.EnsureSuccessStatusCode();
        return await ReadAsync<TResponse>(response, cancellationToken)
            ?? throw new InvalidOperationException("The API returned an empty response.");
    }

    public async Task<TResponse> PutAsync<TRequest, TResponse>(string relativeUri, TRequest request, CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Put, relativeUri, request, cancellationToken);
        response.EnsureSuccessStatusCode();
        return await ReadAsync<TResponse>(response, cancellationToken)
            ?? throw new InvalidOperationException("The API returned an empty response.");
    }

    public async Task DeleteAsync(string relativeUri, CancellationToken cancellationToken = default)
    {
        using var response = await SendAsync(HttpMethod.Delete, relativeUri, cancellationToken: cancellationToken);
        response.EnsureSuccessStatusCode();
    }
}
