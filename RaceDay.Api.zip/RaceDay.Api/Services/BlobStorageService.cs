using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace RaceDay.Api.Services;

public sealed class BlobStorageService(IConfiguration configuration, ILogger<BlobStorageService> logger)
{
    private const long MaxFileSizeBytes = 5 * 1024 * 1024;
    private static readonly HashSet<string> AllowedContentTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp"
    };

    private readonly BlobContainerClient _container = CreateContainer(configuration);

    public async Task<string> UploadAsync(IFormFile file, string folder, CancellationToken cancellationToken = default)
    {
        ValidateFile(file);
        var extension = GetExtension(file.ContentType);
        var blobName = $"{folder.Trim('/')}/{Guid.NewGuid():N}{extension}";
        var blob = _container.GetBlobClient(blobName);

        try
        {
            await _container.CreateIfNotExistsAsync(cancellationToken: cancellationToken);
            await using var stream = file.OpenReadStream();
            await blob.UploadAsync(stream, new BlobUploadOptions
            {
                HttpHeaders = new BlobHttpHeaders { ContentType = file.ContentType }
            }, cancellationToken);
            return blob.Uri.ToString();
        }
        catch (RequestFailedException exception)
        {
            logger.LogError(exception, "Blob upload failed for folder {Folder}.", folder);
            throw new InvalidOperationException("The image could not be uploaded to storage.", exception);
        }
    }

    private static BlobContainerClient CreateContainer(IConfiguration configuration)
    {
        var connectionString = configuration["AzureBlobStorage:ConnectionString"];
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException("Azure Blob Storage is not configured.");
        }

        var containerName = configuration["AzureBlobStorage:ContainerName"];
        return new BlobContainerClient(connectionString, string.IsNullOrWhiteSpace(containerName) ? "raceday-images" : containerName);
    }

    private static void ValidateFile(IFormFile file)
    {
        if (file is null || file.Length == 0)
        {
            throw new ArgumentException("No image file was supplied.");
        }

        if (file.Length > MaxFileSizeBytes)
        {
            throw new ArgumentException("The image must be 5 MB or smaller.");
        }

        if (!AllowedContentTypes.Contains(file.ContentType))
        {
            throw new ArgumentException("Only JPEG, PNG, GIF, and WebP images are supported.");
        }
    }

    private static string GetExtension(string contentType) => contentType.ToLowerInvariant() switch
    {
        "image/jpeg" => ".jpg",
        "image/png" => ".png",
        "image/gif" => ".gif",
        "image/webp" => ".webp",
        _ => throw new ArgumentException("Unsupported image type.")
    };
}
