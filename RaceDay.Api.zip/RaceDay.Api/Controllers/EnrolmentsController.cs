using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
using RaceDay.Api.Security;
using RaceDay.Contracts;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/enrolments")]
public class EnrolmentsController(RaceDayDbContext db) : ControllerBase
{
    [HttpPost, SessionAuthorize("Participant")]
    public async Task<ActionResult<EnrolmentDto>> Create(CreateEnrolmentRequest request, CancellationToken cancellationToken)
    {
        var userId = CurrentUserId();
        var category = await db.Categories.AsNoTracking().SingleOrDefaultAsync(item => item.CategoryId == request.CategoryId, cancellationToken);
        if (category is null) return NotFound(new { message = "The category was not found." });
        if (await db.Enrolments.AnyAsync(item => item.ParticipantId == userId && item.CategoryId == request.CategoryId, cancellationToken)) return Conflict(new { message = "You are already enrolled in this category." });
        if (await db.Enrolments.CountAsync(item => item.CategoryId == request.CategoryId, cancellationToken) >= category.MaxParticipants) return Conflict(new { message = "This category has reached capacity." });

        var enrolment = new Enrolment { CategoryId = request.CategoryId, ParticipantId = userId, Status = "Pending", EnrolmentDate = DateTime.UtcNow };
        db.Enrolments.Add(enrolment);
        await db.SaveChangesAsync(cancellationToken);
        var saved = await db.Enrolments.AsNoTracking()
            .Include(item => item.Participant)
            .Include(item => item.Category).ThenInclude(item => item.Event)
            .SingleAsync(item => item.EnrolmentId == enrolment.EnrolmentId, cancellationToken);
        return CreatedAtAction(nameof(GetMine), new { }, ToDto(saved));
    }

    [HttpGet("mine"), SessionAuthorize("Participant")]
    public async Task<ActionResult<IEnumerable<EnrolmentDto>>> GetMine(CancellationToken cancellationToken) =>
        Ok(await db.Enrolments.AsNoTracking().Where(item => item.ParticipantId == CurrentUserId()).Select(ToDtoExpression).ToListAsync(cancellationToken));

    [HttpGet("event/{eventId:int}"), SessionAuthorize("Organiser")]
    public async Task<ActionResult<IEnumerable<EnrolmentDto>>> GetForEvent(int eventId, CancellationToken cancellationToken)
    {
        if (!await db.Events.AnyAsync(item => item.EventId == eventId && item.OrganiserId == CurrentUserId(), cancellationToken)) return StatusCode(StatusCodes.Status403Forbidden);
        return Ok(await db.Enrolments.AsNoTracking().Where(item => item.Category.EventId == eventId).Select(ToDtoExpression).ToListAsync(cancellationToken));
    }

    [HttpPut("{id:int}/status"), SessionAuthorize("Organiser")]
    public async Task<ActionResult<EnrolmentDto>> UpdateStatus(int id, UpdateEnrolmentStatusRequest request, CancellationToken cancellationToken)
    {
        var allowed = new[] { "Pending", "Confirmed", "Cancelled" };
        if (!allowed.Contains(request.Status, StringComparer.OrdinalIgnoreCase)) return BadRequest(new { message = "Status must be Pending, Confirmed, or Cancelled." });
        var enrolment = await db.Enrolments.Include(item => item.Category).ThenInclude(item => item.Event).SingleOrDefaultAsync(item => item.EnrolmentId == id, cancellationToken);
        if (enrolment is null) return NotFound();
        if (enrolment.Category.Event.OrganiserId != CurrentUserId()) return StatusCode(StatusCodes.Status403Forbidden);
        enrolment.Status = allowed.Single(status => status.Equals(request.Status, StringComparison.OrdinalIgnoreCase));
        await db.SaveChangesAsync(cancellationToken);
        return Ok(ToDto(enrolment));
    }

    private int CurrentUserId() => HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
    private static EnrolmentDto ToDto(Enrolment item) => new() { Id = item.EnrolmentId, ParticipantId = item.ParticipantId, CategoryId = item.CategoryId, ParticipantName = item.Participant.FullName, EventName = item.Category.Event.Name, CategoryName = item.Category.CategoryName, Status = item.Status, EnrolmentDate = item.EnrolmentDate };
    private static readonly System.Linq.Expressions.Expression<Func<Enrolment, EnrolmentDto>> ToDtoExpression = item => new EnrolmentDto { Id = item.EnrolmentId, ParticipantId = item.ParticipantId, CategoryId = item.CategoryId, ParticipantName = item.Participant.FullName, EventName = item.Category.Event.Name, CategoryName = item.Category.CategoryName, Status = item.Status, EnrolmentDate = item.EnrolmentDate };
}
