using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
using RaceDay.Api.Security;
using RaceDay.Contracts;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/results")]
public class ResultsController(RaceDayDbContext db) : ControllerBase
{
    [HttpPost, SessionAuthorize("Organiser")]
    public async Task<ActionResult<ResultDto>> Create(CreateResultRequest request, CancellationToken cancellationToken)
    {
        var enrolment = await db.Enrolments.Include(item => item.Category).ThenInclude(item => item.Event).SingleOrDefaultAsync(item => item.EnrolmentId == request.EnrolmentId, cancellationToken);
        if (enrolment is null) return NotFound(new { message = "The enrolment was not found." });
        if (enrolment.Category.Event.OrganiserId != CurrentUserId()) return StatusCode(StatusCodes.Status403Forbidden);
        if (request.FinishTimeSeconds < 0 || request.FinishPosition < 1 || string.IsNullOrWhiteSpace(request.Status)) return BadRequest(new { message = "Finish time, position, and status must be valid." });
        if (await db.Results.AnyAsync(item => item.EnrolmentId == request.EnrolmentId, cancellationToken)) return Conflict(new { message = "A result already exists for this enrolment." });

        var result = new Result { EnrolmentId = request.EnrolmentId, FinishTimeSeconds = request.FinishTimeSeconds, FinishPosition = request.FinishPosition, Status = request.Status.Trim() };
        db.Results.Add(result);
        await db.SaveChangesAsync(cancellationToken);
        var saved = await db.Results.AsNoTracking()
             .Include(item => item.Enrolment).ThenInclude(item => item.Participant)
            .Include(item => item.Enrolment).ThenInclude(item => item.Category).ThenInclude(item => item.Event)
            .SingleAsync(item => item.ResultId == result.ResultId, cancellationToken);
        return CreatedAtAction(nameof(GetMine), new { }, ToDto(saved));
    }

    [HttpGet("mine"), SessionAuthorize("Participant")]
    public async Task<ActionResult<IEnumerable<ResultDto>>> GetMine(CancellationToken cancellationToken) =>
        Ok(await db.Results.AsNoTracking().Where(result => result.Enrolment.ParticipantId == CurrentUserId()).Select(ToDtoExpression).ToListAsync(cancellationToken));

    [HttpGet("event/{eventId:int}"), SessionAuthorize("Organiser")]
    public async Task<ActionResult<IEnumerable<ResultDto>>> GetForEvent(int eventId, CancellationToken cancellationToken)
    {
        if (!await db.Events.AnyAsync(item => item.EventId == eventId && item.OrganiserId == CurrentUserId(), cancellationToken)) return StatusCode(StatusCodes.Status403Forbidden);
        return Ok(await db.Results.AsNoTracking().Where(result => result.Enrolment.Category.EventId == eventId).Select(ToDtoExpression).ToListAsync(cancellationToken));
    }

    private int CurrentUserId() => HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
    private static ResultDto ToDto(Result item) => new() { Id = item.ResultId, EnrolmentId = item.EnrolmentId, ParticipantName = item.Enrolment.Participant.FullName, EventName = item.Enrolment.Category.Event.Name, CategoryName = item.Enrolment.Category.CategoryName, FinishTimeSeconds = item.FinishTimeSeconds, FinishPosition = item.FinishPosition, Status = item.Status };
    private static readonly System.Linq.Expressions.Expression<Func<Result, ResultDto>> ToDtoExpression = item => new ResultDto { Id = item.ResultId, EnrolmentId = item.EnrolmentId, ParticipantName = item.Enrolment.Participant.FullName, EventName = item.Enrolment.Category.Event.Name, CategoryName = item.Enrolment.Category.CategoryName, FinishTimeSeconds = item.FinishTimeSeconds, FinishPosition = item.FinishPosition, Status = item.Status };
}
