using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
using RaceDay.Api.Security;
using RaceDay.Contracts;

namespace RaceDay.Api.Controllers;

[ApiController]
public class CategoriesController(RaceDayDbContext db) : ControllerBase
{
    [HttpGet("api/events/{eventId:int}/categories")]
    public async Task<ActionResult<IEnumerable<CategoryDto>>> GetForEvent(int eventId, CancellationToken cancellationToken)
    {
        if (!await db.Events.AnyAsync(item => item.EventId == eventId, cancellationToken)) return NotFound();
        return Ok(await db.Categories.AsNoTracking().Where(item => item.EventId == eventId).Select(item => new CategoryDto { Id = item.CategoryId, EventId = item.EventId, EventName = item.Event.Name, CategoryName = item.CategoryName, DistanceKm = item.DistanceKm, EntryFee = item.EntryFee, MaxParticipants = item.MaxParticipants }).ToListAsync(cancellationToken));
    }

    [HttpPost("api/events/{eventId:int}/categories"), SessionAuthorize("Organiser")]
    public async Task<ActionResult<CategoryDto>> Create(int eventId, CreateCategoryRequest request, CancellationToken cancellationToken)
    {
        if (!await OwnsEvent(eventId, cancellationToken)) return StatusCode(StatusCodes.Status403Forbidden);
        if (string.IsNullOrWhiteSpace(request.CategoryName) || request.DistanceKm <= 0 || request.EntryFee < 0 || request.MaxParticipants <= 0) return BadRequest(new { message = "Valid category details are required." });
        var category = new Category { EventId = eventId, CategoryName = request.CategoryName.Trim(), DistanceKm = request.DistanceKm, EntryFee = request.EntryFee, MaxParticipants = request.MaxParticipants };
        db.Categories.Add(category);
        await db.SaveChangesAsync(cancellationToken);
        return CreatedAtAction(nameof(GetForEvent), new { eventId }, new CategoryDto { Id = category.CategoryId, EventId = eventId, CategoryName = category.CategoryName, DistanceKm = category.DistanceKm, EntryFee = category.EntryFee, MaxParticipants = category.MaxParticipants });
    }

    [HttpPut("api/categories/{id:int}"), SessionAuthorize("Organiser")]
    public async Task<ActionResult<CategoryDto>> Update(int id, CreateCategoryRequest request, CancellationToken cancellationToken)
    {
        var category = await db.Categories.Include(item => item.Event).SingleOrDefaultAsync(item => item.CategoryId == id, cancellationToken);
        if (category is null) return NotFound();
        if (category.Event.OrganiserId != CurrentUserId()) return StatusCode(StatusCodes.Status403Forbidden);
        if (string.IsNullOrWhiteSpace(request.CategoryName) || request.DistanceKm <= 0 || request.EntryFee < 0 || request.MaxParticipants <= 0) return BadRequest(new { message = "Valid category details are required." });
        category.CategoryName = request.CategoryName.Trim(); category.DistanceKm = request.DistanceKm; category.EntryFee = request.EntryFee; category.MaxParticipants = request.MaxParticipants;
        await db.SaveChangesAsync(cancellationToken);
        return Ok(new CategoryDto { Id = category.CategoryId, EventId = category.EventId, EventName = category.Event.Name, CategoryName = category.CategoryName, DistanceKm = category.DistanceKm, EntryFee = category.EntryFee, MaxParticipants = category.MaxParticipants });
    }

    [HttpDelete("api/categories/{id:int}"), SessionAuthorize("Organiser")]
    public async Task<IActionResult> Delete(int id, CancellationToken cancellationToken)
    {
        var category = await db.Categories.Include(item => item.Event).SingleOrDefaultAsync(item => item.CategoryId == id, cancellationToken);
        if (category is null) return NotFound();
        if (category.Event.OrganiserId != CurrentUserId()) return StatusCode(StatusCodes.Status403Forbidden);
        db.Categories.Remove(category);
        await db.SaveChangesAsync(cancellationToken);
        return NoContent();
    }

    private int CurrentUserId() => HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
    private async Task<bool> OwnsEvent(int eventId, CancellationToken cancellationToken) => await db.Events.AnyAsync(item => item.EventId == eventId && item.OrganiserId == CurrentUserId(), cancellationToken);
}
