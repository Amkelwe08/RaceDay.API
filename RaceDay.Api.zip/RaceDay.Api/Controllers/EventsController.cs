using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
using RaceDay.Api.Security;
using RaceDay.Api.Services;
using RaceDay.Contracts;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/events")]
public class EventsController(RaceDayDbContext db, BlobStorageService blobStorage) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IEnumerable<EventDto>>> GetAll(CancellationToken cancellationToken) =>
        Ok(await db.Events.AsNoTracking().Select(ToDtoExpression).ToListAsync(cancellationToken));

    [HttpGet("{id:int}")]
    public async Task<ActionResult<EventDto>> Get(int id, CancellationToken cancellationToken)
    {
        var raceEvent = await db.Events.AsNoTracking().Where(item => item.EventId == id).Select(ToDtoExpression).SingleOrDefaultAsync(cancellationToken);
        return raceEvent is null ? NotFound() : Ok(raceEvent);
    }

    [HttpPost("{id:int}/banner"), SessionAuthorize("Organiser")]
    [RequestSizeLimit(5 * 1024 * 1024)]
    public async Task<ActionResult<object>> UploadBanner(int id, IFormFile file, CancellationToken cancellationToken)
    {
        var raceEvent = await db.Events.FindAsync([id], cancellationToken);
        if (raceEvent is null) return NotFound();
        if (raceEvent.OrganiserId != CurrentUserId()) return StatusCode(StatusCodes.Status403Forbidden);

        try
        {
            raceEvent.BannerImageUrl = await blobStorage.UploadAsync(file, "event-banners", cancellationToken);
            await db.SaveChangesAsync(cancellationToken);
            return Ok(new { imageUrl = raceEvent.BannerImageUrl });
        }
        catch (ArgumentException exception)
        {
            return BadRequest(new { message = exception.Message });
        }
        catch (InvalidOperationException)
        {
            return Problem("The event banner could not be uploaded.");
        }
    }

    [HttpGet("mine"), SessionAuthorize("Organiser")]
    public async Task<ActionResult<IEnumerable<EventDto>>> GetMine(CancellationToken cancellationToken)
    {
        var organiserId = CurrentUserId();
        return Ok(await db.Events.AsNoTracking().Where(item => item.OrganiserId == organiserId).Select(ToDtoExpression).ToListAsync(cancellationToken));
    }

    [HttpPost, SessionAuthorize("Organiser")]
    public async Task<ActionResult<EventDto>> Create(CreateEventRequest request, CancellationToken cancellationToken)
    {
        if (!Valid(request)) return BadRequest(new { message = "All event details are required." });
        var raceEvent = new Event
        {
            Name = request.Name.Trim(), Description = request.Description.Trim(), EventDate = request.EventDate,
            Location = request.Location.Trim(), OrganiserId = CurrentUserId(), CreatedAt = DateTime.UtcNow
        };
        db.Events.Add(raceEvent);
        await db.SaveChangesAsync(cancellationToken);
        return CreatedAtAction(nameof(Get), new { id = raceEvent.EventId }, ToDto(raceEvent));
    }

    [HttpPut("{id:int}"), SessionAuthorize("Organiser")]
    public async Task<ActionResult<EventDto>> Update(int id, UpdateEventRequest request, CancellationToken cancellationToken)
    {
        var raceEvent = await db.Events.FindAsync([id], cancellationToken);
        if (raceEvent is null) return NotFound();
        if (raceEvent.OrganiserId != CurrentUserId()) return StatusCode(StatusCodes.Status403Forbidden);
        if (!Valid(request)) return BadRequest(new { message = "All event details are required." });
        raceEvent.Name = request.Name.Trim(); raceEvent.Description = request.Description.Trim(); raceEvent.EventDate = request.EventDate;
        raceEvent.Location = request.Location.Trim();
        await db.SaveChangesAsync(cancellationToken);
        return Ok(ToDto(raceEvent));
    }

    [HttpDelete("{id:int}"), SessionAuthorize("Organiser")]
    public async Task<IActionResult> Delete(int id, CancellationToken cancellationToken)
    {
        var raceEvent = await db.Events.FindAsync([id], cancellationToken);
        if (raceEvent is null) return NotFound();
        if (raceEvent.OrganiserId != CurrentUserId()) return StatusCode(StatusCodes.Status403Forbidden);
        db.Events.Remove(raceEvent);
        await db.SaveChangesAsync(cancellationToken);
        return NoContent();
    }

    private int CurrentUserId() => HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
    private static bool Valid(CreateEventRequest request) => !string.IsNullOrWhiteSpace(request.Name) && !string.IsNullOrWhiteSpace(request.Description) && !string.IsNullOrWhiteSpace(request.Location);
    private static EventDto ToDto(Event item) => new() { Id = item.EventId, OrganiserId = item.OrganiserId, OrganiserName = item.Organiser is null ? string.Empty : item.Organiser.FullName, Name = item.Name, Description = item.Description, EventDate = item.EventDate, Location = item.Location, BannerImageUrl = item.BannerImageUrl, CreatedAt = item.CreatedAt };
    private static readonly System.Linq.Expressions.Expression<Func<Event, EventDto>> ToDtoExpression = item => new EventDto { Id = item.EventId, OrganiserId = item.OrganiserId, OrganiserName = item.Organiser.FullName, Name = item.Name, Description = item.Description, EventDate = item.EventDate, Location = item.Location, BannerImageUrl = item.BannerImageUrl, CreatedAt = item.CreatedAt };
}
