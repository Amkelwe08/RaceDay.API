using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
using RaceDay.Api.Security;
using RaceDay.Contracts;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController(RaceDayDbContext db, IPasswordService passwords) : ControllerBase
{
    [HttpPost("register")]
    public async Task<ActionResult<AuthResponse>> Register(RegisterRequest request, CancellationToken cancellationToken)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        const string roleName = "Participant";

        if (string.IsNullOrWhiteSpace(request.FullName) ||
            string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(request.PhoneNumber) || string.IsNullOrWhiteSpace(request.Password) ||
            request.Password.Length < 8)
        {
            return BadRequest(new { message = "A full name, email, phone number, and an eight-character password are required." });
        }

        if (await db.Users.AnyAsync(user => user.Email == email, cancellationToken))
        {
            return Conflict(new { message = "An account with that email already exists." });
        }

        var role = await db.Roles.SingleAsync(role => role.RoleName == roleName, cancellationToken);
        var user = new AppUser
        {
            FullName = request.FullName.Trim(),
            Email = email,
            PasswordHash = passwords.Hash(request.Password),
            PhoneNumber = request.PhoneNumber.Trim(),
            RoleId = role.RoleId,
            CreatedAt = DateTime.UtcNow
        };

        db.Users.Add(user);
        await db.SaveChangesAsync(cancellationToken);
        SetSession(user, role.RoleName);

        return Created("api/profile/me", ToAuthResponse(user, role.RoleName));
    }

    [HttpPost("login")]
    public async Task<ActionResult<AuthResponse>> Login(LoginRequest request, CancellationToken cancellationToken)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await db.Users.Include(user => user.Role).SingleOrDefaultAsync(user => user.Email == email, cancellationToken);

        if (user is null || !passwords.Verify(request.Password, user.PasswordHash))
        {
            return Unauthorized(new { message = "Invalid email or password." });
        }

        SetSession(user, user.Role.RoleName);
        return Ok(ToAuthResponse(user, user.Role.RoleName));
    }

    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.Session.CommitAsync();
        HttpContext.Session.Clear();
        return NoContent();
    }

    private void SetSession(AppUser user, string role)
    {
        HttpContext.Session.SetInt32(SessionKeys.UserId, user.UserId);
        HttpContext.Session.SetString(SessionKeys.Role, role);
    }

    private static AuthResponse ToAuthResponse(AppUser user, string role) => new()
    {
        Token = "session-cookie",
        ExpiresAt = DateTime.UtcNow.AddHours(2),
        User = new ProfileDto
        {
            Id = user.UserId,
            FullName = user.FullName,
            Email = user.Email,
            PhoneNumber = user.PhoneNumber,
            CreatedAt = user.CreatedAt,
            Role = role
        }
    };
}
