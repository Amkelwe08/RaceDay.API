using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Security;
using RaceDay.Api.Services;
using RaceDay.Contracts;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/profile")]
[SessionAuthorize("Organiser", "Participant")]
public class ProfileController(RaceDayDbContext db, BlobStorageService blobStorage) : ControllerBase
{
    [HttpGet("me")]
    public async Task<ActionResult<ProfileDto>> GetMe(CancellationToken cancellationToken)
    {
        var user = await GetCurrentUser(cancellationToken);
        return user is null ? Unauthorized() : Ok(ToDto(user));
    }

    [HttpPost("me/image")]
    [RequestSizeLimit(5 * 1024 * 1024)]
    public async Task<ActionResult<object>> UploadImage(IFormFile file, CancellationToken cancellationToken)
    {
        var user = await GetCurrentUser(cancellationToken);
        if (user is null) return Unauthorized();

        try
        {
            user.ProfileImageUrl = await blobStorage.UploadAsync(file, "profile-images", cancellationToken);
            await db.SaveChangesAsync(cancellationToken);
            return Ok(new { imageUrl = user.ProfileImageUrl });
        }
        catch (ArgumentException exception)
        {
            return BadRequest(new { message = exception.Message });
        }
        catch (InvalidOperationException)
        {
            return Problem("The profile image could not be uploaded.");
        }
    }

    [HttpPut("me")]
    public async Task<ActionResult<ProfileDto>> UpdateMe(UpdateProfileRequest request, CancellationToken cancellationToken)
    {
        var user = await GetCurrentUser(cancellationToken);
        if (user is null)
        {
            return Unauthorized();
        }

        var email = request.Email.Trim().ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(request.FullName) || string.IsNullOrWhiteSpace(email))
        {
            return BadRequest(new { message = "First name, last name, and email are required." });
        }

        if (await db.Users.AnyAsync(other => other.UserId != user.UserId && other.Email == email, cancellationToken))
        {
            return Conflict(new { message = "An account with that email already exists." });
        }

        user.FullName = request.FullName.Trim();
        user.Email = email;
        user.PhoneNumber = request.PhoneNumber.Trim();
        await db.SaveChangesAsync(cancellationToken);

        return Ok(ToDto(user));
    }

    private async Task<Models.AppUser?> GetCurrentUser(CancellationToken cancellationToken)
    {
        var userId = HttpContext.Session.GetInt32(SessionKeys.UserId);
        return userId is null
            ? null
            : await db.Users.Include(user => user.Role).SingleOrDefaultAsync(user => user.UserId == userId, cancellationToken);
    }

    private static ProfileDto ToDto(Models.AppUser user) => new()
    {
        Id = user.UserId,
        FullName = user.FullName,
        Email = user.Email,
        PhoneNumber = user.PhoneNumber,
        Role = user.Role.RoleName,
        ProfileImageUrl = user.ProfileImageUrl,
        CreatedAt = user.CreatedAt
    };
}
