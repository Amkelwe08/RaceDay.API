using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;

namespace RaceDay.Api.Data;

public class RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : DbContext(options)
{
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<Event> Events => Set<Event>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Enrolment> Enrolments => Set<Enrolment>();
    public DbSet<Result> Results => Set<Result>();
    public DbSet<Role> Roles => Set<Role>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(role => role.RoleId);
            entity.HasIndex(role => role.RoleName).IsUnique();
            entity.Property(role => role.RoleName).HasMaxLength(50).IsRequired();
            entity.HasData(
                new Role { RoleId = 1, RoleName = "Organiser" },
                new Role { RoleId = 2, RoleName = "Participant" });
        });

        modelBuilder.Entity<AppUser>(entity =>
        {
            entity.HasKey(user => user.UserId);
            entity.HasIndex(user => user.Email).IsUnique();
            entity.Property(user => user.Email).HasMaxLength(256).IsRequired();
            entity.Property(user => user.FullName).HasMaxLength(200).IsRequired();
            entity.Property(user => user.PasswordHash).IsRequired();
            entity.Property(user => user.PhoneNumber).HasMaxLength(30).IsRequired();
            entity.Property(user => user.ProfileImageUrl).HasMaxLength(2048);

            entity.HasOne(user => user.Role)
                .WithMany(role => role.Users)
                .HasForeignKey(user => user.RoleId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Event>(entity =>
        {
            entity.HasKey(raceEvent => raceEvent.EventId);
            entity.Property(raceEvent => raceEvent.Name).HasMaxLength(200).IsRequired();
            entity.Property(raceEvent => raceEvent.BannerImageUrl).HasMaxLength(2048);
            entity.Property(raceEvent => raceEvent.CreatedAt).IsRequired();

            entity.HasOne(raceEvent => raceEvent.Organiser)
                .WithMany(user => user.OrganisedEvents)
                .HasForeignKey(raceEvent => raceEvent.OrganiserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(category => category.CategoryId);
            entity.Property(category => category.CategoryName).HasMaxLength(100).IsRequired();
            entity.Property(category => category.DistanceKm).HasPrecision(10, 2);
            entity.Property(category => category.EntryFee).HasPrecision(10, 2);

            entity.HasOne(category => category.Event)
                .WithMany(raceEvent => raceEvent.Categories)
                .HasForeignKey(category => category.EventId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Enrolment>(entity =>
        {
            entity.HasKey(enrolment => enrolment.EnrolmentId);
            entity.HasIndex(enrolment => new { enrolment.ParticipantId, enrolment.CategoryId })
                .IsUnique();

            entity.HasOne(enrolment => enrolment.Participant)
                .WithMany(user => user.Enrolments)
                .HasForeignKey(enrolment => enrolment.ParticipantId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(enrolment => enrolment.Category)
                .WithMany(category => category.Enrolments)
                .HasForeignKey(enrolment => enrolment.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Result>(entity =>
        {
            entity.HasKey(result => result.ResultId);
            entity.Property(result => result.FinishTimeSeconds).HasPrecision(10, 3);

            entity.HasOne(result => result.Enrolment)
                .WithOne(enrolment => enrolment.Result)
                .HasForeignKey<Result>(result => result.EnrolmentId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}