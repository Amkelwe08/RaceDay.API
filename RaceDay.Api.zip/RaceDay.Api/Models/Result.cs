namespace RaceDay.Api.Models;

public class Result
{
    public int ResultId { get; set; }
    public int EnrolmentId { get; set; }
    public decimal FinishTimeSeconds { get; set; }
    public int FinishPosition { get; set; }
    public string Status { get; set; } = string.Empty;

    public Enrolment Enrolment { get; set; } = null!;
}
